import jwt from "jsonwebtoken";

const secretKey = process.env.JWT_SECRET;

export function authMiddleware(req, res, next) {
    try {
        if (!secretKey) {
            console.error("JWT_SECRET is not defined in environment variables");
            return res.status(500).json({ message: "Server configuration error" });
        }

        const authHeader = req.headers.authorization;
        
        // Check if the Authorization header is present and starts with "Bearer "
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({ message: "Unauthorized: Authentication token is required" });
        }

        // Extract the token from Bearer token in the Authorization header
        const token = authHeader.split(" ")[1];

        if (!token) {
            return res.status(401).json({ message: "Unauthorized: Authentication token is required" });
        }

        const decodedToken = jwt.verify(token, secretKey);

        req.user = {
            id: decodedToken.id, 
            username: decodedToken.username,
            isAdmin: decodedToken.isAdmin
        };

        next();
    } catch (error) {
        console.error("Authentication error: ", error.message);

        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ message: "Token expired" });
        }

        res.status(401).json({ message: "Unauthorized" });
    }
}
